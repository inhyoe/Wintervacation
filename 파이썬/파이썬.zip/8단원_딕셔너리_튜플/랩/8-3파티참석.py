
partyA = set(["Park","Kim",'Lee'])
partyB = set(['Park','Choi'])
print('2개 파티에 참석한 사람은 다음과 같습니다')
print(partyA&partyB)