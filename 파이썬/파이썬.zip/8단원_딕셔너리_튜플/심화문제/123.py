fruit = input('사과 배 수박 귤 포도 가격을 공백으로 구분하여 입력')
split_fruit_value=fruit.split()
print(split_fruit_value[0])
fruits_dic = {'사과':0 , '배':0,'수박':0,'귤':0,'포도':0}
