사전 = {}
사전['one'] = 1
사전['two'] = 2
print(사전.keys())