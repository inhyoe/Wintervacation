slist = ['kim',178.9,'park',175,'lee',176]

slist[3] = 180

print(slist)

# 혹은 slist.insert(인덱스값,수정값)
# 인덱스를 이용하여 값을 수정 할 수 있다.
4