fruit_list  =  ['orange','banana','kiwi','apple','melon']

for i in fruit_list:
    print(i ,': 문자열의 길이',len(i)) # 문자열의 길이를 출력한다.