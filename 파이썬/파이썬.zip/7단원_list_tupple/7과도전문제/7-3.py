list1 = ['I like','I love']
list2 = ['pancakes.','kiwi juice.','espresso.']

for i in range(len(list1)):
    for k in range(len(list2)):
        print(list1[i],list2[k])
        # 리스트의 원소들을 순서대로 나열한다