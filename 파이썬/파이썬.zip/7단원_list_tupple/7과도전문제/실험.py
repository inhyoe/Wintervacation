print(list(range(10)))
a = range(10)
print(a)
fruit_list  =  ['banana','orange','kiwi','apple','melon']
print(range(len(fruit_list)))
print('-----------')
print(range(len(fruit_list[1])))
for i in range(len(fruit_list)):
    print(len(fruit_list[i])) 
print(fruit_list[3])