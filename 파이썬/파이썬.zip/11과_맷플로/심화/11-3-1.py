import matplotlib.pyplot as plt
import numpy as np

x = np.random.randint(0,50,15)
y = np.random.randint(0,50,15)

plt.scatter(x,y)
plt.show()