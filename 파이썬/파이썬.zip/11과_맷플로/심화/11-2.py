import matplotlib.pyplot as plt
import numpy as np


sin = np.sin()
cos = np.cos()
