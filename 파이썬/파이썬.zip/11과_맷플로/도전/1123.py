n_list = [100,200]
range(1,11)
x = list(range(1,11))

print(x)


n_list = n_list + x 

print(n_list)