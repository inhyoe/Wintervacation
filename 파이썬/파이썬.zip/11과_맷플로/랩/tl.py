import random
print(random.uniform(-3,2))