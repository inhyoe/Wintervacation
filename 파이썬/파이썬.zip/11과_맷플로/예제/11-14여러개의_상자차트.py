import numpy as np
import matplotlib.pyplot as plt

data = [1,2,3,4,5]
data2 = [1,2,3,4,5]

plt.boxplot([data,data2])

plt.show()