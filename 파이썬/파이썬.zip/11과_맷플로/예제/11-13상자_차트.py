import numpy as np
import matplotlib.pyplot as plt

random_data = np.random.randn(100)
plt.boxplot(random_data)
plt.show()