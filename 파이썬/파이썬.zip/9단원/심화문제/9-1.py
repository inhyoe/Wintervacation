name = input('이름을 입력하세요')
split = name.split()
print(split[1])