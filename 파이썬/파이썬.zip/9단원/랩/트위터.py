t  = "There's a reason some people are working to make it harder to vote, epecially for people of color. It's Because when we show up, things change"
print(len(t.split()))
t = [0,1,2,3]
print(len(t))