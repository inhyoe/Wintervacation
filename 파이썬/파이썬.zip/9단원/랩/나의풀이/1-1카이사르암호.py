import string

알파벳 = string.ascii_uppercase
카이사르_암호 = 알파벳[3:] + 알파벳[:3]
print(카이사르_암호) # 완성.

입력값 = input("바꿀 명령을 입력하세요.")
배열 = []
for i in range(len(입력값)):
    배열 = 

