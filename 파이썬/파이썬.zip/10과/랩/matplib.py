years = [ 1950, 1960,1970, 1980, 1990, 2000, 2010]
print(range(len(years)))