import numpy as np

salary = np.array([220,250,230])

salary = salary + 100
print(salary)