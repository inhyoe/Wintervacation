import numpy as np

a = np.array(range(1,11)) + np.array(range(10,101,10))

print(a.shape)
print(a.size)