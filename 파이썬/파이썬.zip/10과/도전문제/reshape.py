import numpy as np

y = np.arange(12)
print(y)

y.reshape(3,4)
print(y.reshape(3,4.))