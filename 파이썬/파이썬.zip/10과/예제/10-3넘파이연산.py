import numpy as np

salary = np.array([220,250,230])

bonus = salary + 100
tobonus = salary * 0.0002
print(bonus)
print(tobonus)