import numpy as np
mid_scores = np.array([10,20,30])
final_scores = np.array([60,70,80])

total = mid_scores + final_scores
print('시험 성적 합계: ' , total)
print('평균값 : ' ,total/2)