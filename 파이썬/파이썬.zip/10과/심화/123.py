import numpy as np

print(np.arange(12).reshape(2,2,3))
# 3차원 2개로 2행씩 3열로
# (4,2,2)
# 3차원 4개로 2행씩 2열로